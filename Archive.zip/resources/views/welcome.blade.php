<x-app-layout>
    <div class="py-4 mt-12 max-w-3xl bg-white rounded-lg mx-auto p-4 text-center">
        <h1 class="text-2xl font-black mb-5">This is the homepage</h1>

        <a href="/forum">
            <x-jet-button>See Forum</x-jet-button>
        </a>
    </div>
</x-app-layout>
