@extends('admin.layout.app')


@section('content')

    @livewire('admin.comment.main')

@endsection


