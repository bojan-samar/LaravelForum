<x-app-layout>
    <style>
        body {
            background: #f3f4f6 !important;
        }
    </style>
    <section class="container py-12 max-w-3xl mx-auto">
        @livewire('forum.saved', key('forum-saved'))
    </section>
</x-app-layout>
