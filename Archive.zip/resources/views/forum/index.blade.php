<x-app-layout>
    <style>
        body {
            background: #f3f4f6 !important;
        }
    </style>
    @livewire('forum.main', key('forum'))
</x-app-layout>
