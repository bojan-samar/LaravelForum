<tr {{ $attributes->merge(['class' => 'focus-within:bg-gray-50 overflow-hidden hover:bg-gray-50']) }} >
    {{$slot}}
</tr>
