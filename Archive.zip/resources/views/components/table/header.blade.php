<th class="px-6 py-3 font-black tracking-wider uppercase text-xs">
    {{$slot}}
</th>