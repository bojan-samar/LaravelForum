<td class="border-t">
    <span class="text-gray-700 px-6 py-2 flex items-center">
        {{$slot}}
    </span>
</td>
