<?php return array (
  'admin.comment.index' => 'App\\Http\\Livewire\\Admin\\Comment\\Index',
  'admin.comment.main' => 'App\\Http\\Livewire\\Admin\\Comment\\Main',
  'admin.comment.show' => 'App\\Http\\Livewire\\Admin\\Comment\\Show',
  'comment.comment' => 'App\\Http\\Livewire\\Comment\\Comment',
  'comment.comments' => 'App\\Http\\Livewire\\Comment\\Comments',
  'forum.create' => 'App\\Http\\Livewire\\Forum\\Create',
  'forum.index' => 'App\\Http\\Livewire\\Forum\\Index',
  'forum.main' => 'App\\Http\\Livewire\\Forum\\Main',
  'forum.saved' => 'App\\Http\\Livewire\\Forum\\Saved',
  'forum.show' => 'App\\Http\\Livewire\\Forum\\Show',
);