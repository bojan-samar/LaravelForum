## Laravel Forum

Forum where users can create a post, leave comments and reply to comments. Users can also save their favorite post for later viewing.

## Instructions
1. Clone the repo
2. Run "npm install && npm run dev"
3. Run "php artisan migrate"
