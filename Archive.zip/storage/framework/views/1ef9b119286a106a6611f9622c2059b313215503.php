<tr <?php echo e($attributes->merge(['class' => 'focus-within:bg-gray-50 overflow-hidden hover:bg-gray-50'])); ?> >
    <?php echo e($slot); ?>

</tr>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/components/table/row.blade.php ENDPATH**/ ?>