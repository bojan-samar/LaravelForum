<div class="bg-white mt-5 overflow-hidden rounded-lg">
    <div class="overflow-x-auto" style="overflow-x: auto;">
        <table class="w-full whitespace-no-wrap bg-white overflow-hidden table-striped">
            <thead>
                <tr class="text-left">
                    <?php echo e($heading); ?>

                </tr>
            </thead>
            <tbody>
                <?php echo e($body); ?>

            </tbody>
        </table>
    </div>
</div><?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/components/table/main.blade.php ENDPATH**/ ?>