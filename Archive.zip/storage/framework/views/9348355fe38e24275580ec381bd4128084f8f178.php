<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.comment.main')->html();
} elseif ($_instance->childHasBeenRendered('iq8WkSM')) {
    $componentId = $_instance->getRenderedChildComponentId('iq8WkSM');
    $componentTag = $_instance->getRenderedChildComponentTagName('iq8WkSM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iq8WkSM');
} else {
    $response = \Livewire\Livewire::mount('admin.comment.main');
    $html = $response->html();
    $_instance->logRenderedChild('iq8WkSM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/admin/forum/comment.blade.php ENDPATH**/ ?>