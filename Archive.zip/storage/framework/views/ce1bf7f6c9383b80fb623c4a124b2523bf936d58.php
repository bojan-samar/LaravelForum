<th class="px-6 py-3 font-black tracking-wider uppercase text-xs">
    <?php echo e($slot); ?>

</th><?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/components/table/header.blade.php ENDPATH**/ ?>