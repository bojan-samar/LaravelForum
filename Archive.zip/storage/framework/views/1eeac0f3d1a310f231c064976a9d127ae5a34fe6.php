<div class="flex items-center mb-2">
    <div>
        <a href="<?php echo e(route('forum.user', $user['uuid'])); ?>">
            <img class="h-12 w-12 rounded-full" src="<?php echo e($user['profile_photo_url']); ?>" alt="<?php echo e($user['name']); ?>">
        </a>
    </div>
    <div class="text-xs ml-3">
        <a href="<?php echo e(route('forum.user', $user['uuid'])); ?>">
            <?php echo e($user['alias']); ?>

        </a>
        <span class="text-gray-400"> | <?php echo e($created_at); ?></span>
    </div>
</div>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/forum/_author.blade.php ENDPATH**/ ?>