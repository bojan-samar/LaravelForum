<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        body {
            background: #f3f4f6 !important;
        }
    </style>

    <section class="max-w-3xl mx-auto pt-8">
        <div class="flex items-center">
            <div class="p-4">
                <img style="max-height: 10rem" class="rounded-full" src="<?php echo e($user['profile_photo_url']); ?>" alt="<?php echo e($user['name']); ?>">
            </div>
            <div class="p-4">
                <div><b>Name:</b> <?php echo e($user->alias); ?></div>
                <div><b>Posts: </b> <?php echo e($user->forums->count()); ?></div>
            </div>
        </div>
    </section>


    <section class="max-w-3xl mx-auto py-5">
        <h2 class="font-black text-3xl mb-5 text-center">Latest Posts</h2>
        <?php $__empty_1 = true; $__currentLoopData = $user->forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="shadow rounded-lg p-4 bg-white mb-5">

                <div class="font-bold">
                    <a href="<?php echo e(route('forum.show', $forum->slug)); ?>">
                        <h2><?php echo e($forum->title); ?></h2>
                    </a>
                </div>
                <div class="text-base">
                    <?php echo e($forum->body); ?>

                </div>

                <div class="mt-5">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                    </svg>
                    <span class="text-base"><?php echo e($forum->comments->count()); ?></span>

                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 inline ml-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span class="text-base"><?php echo e($forum->created_at->diffForHumans()); ?></span>
                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="shadow rounded-lg p-4 bg-white mb-5 text-center font-bold text-2xl">
                No Posts
            </div>

        <?php endif; ?>
    </section>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/forum/user.blade.php ENDPATH**/ ?>