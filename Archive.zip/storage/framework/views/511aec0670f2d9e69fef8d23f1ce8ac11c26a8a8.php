<section>

<?php $__empty_1 = true; $__currentLoopData = $saves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


    <div class="shadow rounded-lg p-4 bg-white mb-5">

        <?php echo $__env->make('forum._author', [ 'user' => $save['user'], 'created_at' => \Carbon\Carbon::create($save['created_at'])->diffForHumans() ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="font-bold">
            <a href="<?php echo e(route('forum.show', $save['forum']['slug'] )); ?>">
                <h2><?php echo e($save['forum']['title']); ?></h2>
            </a>
        </div>

        <div class="text-base">
            <?php echo e($save['forum']['body']); ?>

        </div>


        <div class="mt-5">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => 'save('.e($loop->index).')','size' => 'md','class' => 'mr-2']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'save('.e($loop->index).')','size' => 'md','class' => 'mr-2']); ?>
                <?php if($save['saved']): ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bookmark-fill inline mr-1 text-red-600" viewBox="0 0 16 16">
                        <path d="M2 2v13.5a.5.5 0 0 0 .74.439L8 13.069l5.26 2.87A.5.5 0 0 0 14 15.5V2a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/>
                    </svg>
                    Unsave
                <?php else: ?>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                    </svg>
                    Save
                <?php endif; ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <section class="shadow rounded-lg p-4 bg-white mb-5 text-center font-bold text-2xl">
        No Saved Posts
    </section>

<?php endif; ?>
</section>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/livewire/forum/saved.blade.php ENDPATH**/ ?>