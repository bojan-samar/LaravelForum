<section>
    <?php switch($step):

        case ('index'): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.comment.index')->html();
} elseif ($_instance->childHasBeenRendered('index')) {
    $componentId = $_instance->getRenderedChildComponentId('index');
    $componentTag = $_instance->getRenderedChildComponentTagName('index');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('index');
} else {
    $response = \Livewire\Livewire::mount('admin.comment.index');
    $html = $response->html();
    $_instance->logRenderedChild('index', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php break; ?>

        <?php case ('show'): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.comment.show', ['commentId' => $commentSelected])->html();
} elseif ($_instance->childHasBeenRendered('admin-comment-show')) {
    $componentId = $_instance->getRenderedChildComponentId('admin-comment-show');
    $componentTag = $_instance->getRenderedChildComponentTagName('admin-comment-show');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('admin-comment-show');
} else {
    $response = \Livewire\Livewire::mount('admin.comment.show', ['commentId' => $commentSelected]);
    $html = $response->html();
    $_instance->logRenderedChild('admin-comment-show', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php break; ?>

        <?php default: ?>
            Nothing

    <?php endswitch; ?>

</section>

<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/livewire/admin/comment/main.blade.php ENDPATH**/ ?>