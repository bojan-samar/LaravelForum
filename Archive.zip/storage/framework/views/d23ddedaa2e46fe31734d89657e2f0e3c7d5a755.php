<td class="border-t">
    <span class="text-gray-700 px-6 py-2 flex items-center">
        <?php echo e($slot); ?>

    </span>
</td>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/components/table/cell.blade.php ENDPATH**/ ?>