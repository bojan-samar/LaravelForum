<section>
    <h1 class="text-xl font-bold">Recent Comments</h1>

    <?php if (isset($component)) { $__componentOriginal419ce5d608ee8adf07826ba5107d983b88545e95 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Main::class, []); ?>
<?php $component->withName('table.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading'); ?> 
            <?php if (isset($component)) { $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Header::class, []); ?>
<?php $component->withName('table.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>ID <?php if (isset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e)): ?>
<?php $component = $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e; ?>
<?php unset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Header::class, []); ?>
<?php $component->withName('table.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Comment <?php if (isset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e)): ?>
<?php $component = $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e; ?>
<?php unset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Header::class, []); ?>
<?php $component->withName('table.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Created At <?php if (isset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e)): ?>
<?php $component = $__componentOriginal93a64aff427b37447c6ae280100639d5b005438e; ?>
<?php unset($__componentOriginal93a64aff427b37447c6ae280100639d5b005438e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('body'); ?> 
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal194b1498e07d41898937a1db3b7c1f688ce9186c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Row::class, []); ?>
<?php $component->withName('table.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'cursor-pointer','wire:click' => '$emitUp(\'selectComment\', '.e($comment->id).')']); ?>
                    <?php if (isset($component)) { $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Cell::class, []); ?>
<?php $component->withName('table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($comment->id); ?> <?php if (isset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd)): ?>
<?php $component = $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd; ?>
<?php unset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Cell::class, []); ?>
<?php $component->withName('table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($comment->body); ?> <?php if (isset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd)): ?>
<?php $component = $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd; ?>
<?php unset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table\Cell::class, []); ?>
<?php $component->withName('table.cell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($comment->created_at->diffForHumans()); ?> <?php if (isset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd)): ?>
<?php $component = $__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd; ?>
<?php unset($__componentOriginal5ea3c1949bc7a2dabcc29bf3097dfc8bf8e209fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                 <?php if (isset($__componentOriginal194b1498e07d41898937a1db3b7c1f688ce9186c)): ?>
<?php $component = $__componentOriginal194b1498e07d41898937a1db3b7c1f688ce9186c; ?>
<?php unset($__componentOriginal194b1498e07d41898937a1db3b7c1f688ce9186c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal419ce5d608ee8adf07826ba5107d983b88545e95)): ?>
<?php $component = $__componentOriginal419ce5d608ee8adf07826ba5107d983b88545e95; ?>
<?php unset($__componentOriginal419ce5d608ee8adf07826ba5107d983b88545e95); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</section>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/livewire/admin/comment/index.blade.php ENDPATH**/ ?>