<section>
    <?php switch($step):

        case ('create'): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('forum.create')->html();
} elseif ($_instance->childHasBeenRendered('create')) {
    $componentId = $_instance->getRenderedChildComponentId('create');
    $componentTag = $_instance->getRenderedChildComponentTagName('create');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('create');
} else {
    $response = \Livewire\Livewire::mount('forum.create');
    $html = $response->html();
    $_instance->logRenderedChild('create', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php break; ?>

        <?php default: ?>
            <section class="container py-12 max-w-3xl mx-auto">
                <div class="text-right mb-5">
                    <a href="/forum-saved">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'mr-2 relative']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-2 relative']); ?>
                            Saved Posts
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></a>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => '$set(\'step\', \'create\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'step\', \'create\')','wire:loading.attr' => 'disabled']); ?>
                        New Post
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('forum.index')->html();
} elseif ($_instance->childHasBeenRendered('index')) {
    $componentId = $_instance->getRenderedChildComponentId('index');
    $componentTag = $_instance->getRenderedChildComponentTagName('index');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('index');
} else {
    $response = \Livewire\Livewire::mount('forum.index');
    $html = $response->html();
    $_instance->logRenderedChild('index', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>

    <?php endswitch; ?>
</section>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/livewire/forum/main.blade.php ENDPATH**/ ?>