<section id="comments" class="bg-gray-100 py-12">
    <div class="container mx-auto">
        <div class="shadow rounded-lg p-4 bg-white">

            <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="font-bold mb-5">Comments</div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment.comment', ['comment' => $comment])->html();
} elseif ($_instance->childHasBeenRendered($comment->id)) {
    $componentId = $_instance->getRenderedChildComponentId($comment->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($comment->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($comment->id);
} else {
    $response = \Livewire\Livewire::mount('comment.comment', ['comment' => $comment]);
    $html = $response->html();
    $_instance->logRenderedChild($comment->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <div class="ml-14">
                    <?php $__currentLoopData = $comment->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment.comment', ['comment' => $child])->html();
} elseif ($_instance->childHasBeenRendered(time().$child->id)) {
    $componentId = $_instance->getRenderedChildComponentId(time().$child->id);
    $componentTag = $_instance->getRenderedChildComponentTagName(time().$child->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time().$child->id);
} else {
    $response = \Livewire\Livewire::mount('comment.comment', ['comment' => $child]);
    $html = $response->html();
    $_instance->logRenderedChild(time().$child->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="font-bold">No Comments Yet</div>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <div class="mt-10">

                    <form id="new-comment" wire:submit.prevent="postComment" class="max-w-2xl">
                        <textarea id="reply" type="text"
                                  wire:model.defer="newCommentState.body"
                                  class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm block mt-1 w-full <?php $__errorArgs = ['newCommentState.body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  name="reply"
                                  rows="5">
                        </textarea>

                        <?php $__errorArgs = ['newCommentState.body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'mt-3']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
                            Comment
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </form>
                </div>
            <?php else: ?>
                <div class="text-base">
                    <a href="/login" class="text-blue-600">Log In</a> or <a href="/register" class="text-blue-600">Register</a> To Reply
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>
<?php /**PATH /Users/boki/Documents/Websites/LaravelForum/resources/views/livewire/comment/comments.blade.php ENDPATH**/ ?>